#define GAME_OVER_WIDTH 240
#define GAME_OVER_HEIGHT 160
const unsigned short Game_Over_data[38400];
