#define SUN_WIDTH 25
#define SUN_HEIGHT 25
const unsigned short Sun_data[625];
