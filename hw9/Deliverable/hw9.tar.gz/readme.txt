 ______________________________________________________________________________
| ___________________________________________________________________________  |
| |    _______    __        __      ___       __   __                        | |
| |   /  ___  \  |  \ \  / |__ |\ |  |  |  | |__| |__                        | |
| |  |  |___|  | |__/  \/  |__ | \|  |  |__| |  \ |__                        | |
| |  |   ___   |          _   _    ___      _                                | |
| |  |  |   |  |         | | |_     |  |_| |_                                | |
| |  |__|   |__|         |_| |      |  | | |_                                | |
| |   _______      ______    ______                                          | |
| |  |   __   \   |   ___|  |  ___  \                                        | |
| |  |  |___\  |  |  |___   |  |  \  |                                       | |
| |  |   ___   |  |   ___|  |  |   | |                                       | |
| |  |  |   |  |  |  |___   |  |__/  |                                       | |
| |  |__|   |__|  |______|  |_______/                                        | |
| |   ________    ______    __     __    _______     _______      ______     | |
| |  |  ______|  |  __  |  |  |   |  |  /  ___  \   |   __   \   |   ___|    | |
| |  |  |_____   | |  | |  |  |   |  | |  |___|  |  |  |___\  |  |  |___     | |
| |  |______  |  | |  |_|  |  |   |  | |   ___   |  |   ___   |  |   ___|    | |
| |   ______| |  | |__   \ |  |___|  | |  |   |  |  |  |   |  |  |  |___     | |
| |  |________|  |_____\_|  \_______/  |__|   |__|  |__|   |__|  |______|    | |
| |__________________________________________________________________________| |
|______________________________________________________________________________|
//jesus the above took waaay too long

 =====================
|| Table of Contents ||
 =====================
|                     |
|  1. Introduction    |
|  2. Controls        |
|  3. Resources       |
|  4. Author          |
|_____________________|

1. Introduction
The Red Square is in troubling! it is trying to run away from the bad guys!
Help Red Square try to run as far as he can while avoiding the obstacles on the
way. Remember, the Red Square has a super power, Blue Square Mode! During this
time, Red Square slows down time around him, so use it to buy time to avoid more
obstacles. Blue Square Mode is super tiring for the Red Square though, so do use
the Super Mode with caution!

2. Controls
  Left, Right  : Lateral Movement
      Up       : Jump
    Start      : Start Game / Return to Title
    Select     : Pause / Unpause
      A        : Blue Square Mode (WARNING)

3. Resources
Lecture Codes used after alterations.

4. Author
Name : Jaemin Park
GTID : 902912537
