#define START_SCREEN_WIDTH 240
#define START_SCREEN_HEIGHT 160
const unsigned short Start_Screen_data[38400];
